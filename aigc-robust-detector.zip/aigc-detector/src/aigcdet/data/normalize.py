"""Canonicalisation: make every image look the same *except* for its content.

The most common way an AIGC detector cheats is that the two classes were
collected differently. Real photos come from COCO at 640x480 as quality-75
JPEGs with EXIF; the generated set arrives as 1024x1024 lossless PNGs straight
from a diffusion pipeline. A classifier can hit 99% on that split without ever
looking at a pixel of content - it only has to notice the file is square, or
large, or has no quantisation table.

`canonicalize` removes those handles before anything else touches the image:

  1. RGB, EXIF dropped, alpha flattened
  2. resized so the short side is a fixed length, aspect ratio preserved
  3. centre-cropped to a fixed square
  4. re-encoded once as JPEG at a fixed quality

After this, both classes have identical resolution, identical aspect ratio,
identical container and one identical round of JPEG history. Whatever accuracy
survives is coming from image content, which is the only kind that transfers.

We report accuracy before *and* after canonicalisation in the write-up; the gap
is the size of the shortcut we removed.
"""

from __future__ import annotations

import io
from dataclasses import dataclass
from pathlib import Path

from PIL import Image


@dataclass(frozen=True)
class CanonicalSpec:
    short_side: int = 256
    square: int = 224
    jpeg_quality: int = 92

    def as_dict(self) -> dict:
        return {
            "short_side": self.short_side,
            "square": self.square,
            "jpeg_quality": self.jpeg_quality,
        }


CANONICAL_SPEC = CanonicalSpec()


def canonicalize(img: Image.Image, spec: CanonicalSpec = CANONICAL_SPEC) -> Image.Image:
    """Return a size-, format- and history-normalised copy of `img`."""
    img = img.convert("RGB")

    w, h = img.size
    if min(w, h) != spec.short_side:
        scale = spec.short_side / float(min(w, h))
        img = img.resize((max(1, round(w * scale)), max(1, round(h * scale))), Image.BICUBIC)

    w, h = img.size
    side = min(spec.square, w, h)
    left, top = (w - side) // 2, (h - side) // 2
    img = img.crop((left, top, left + side, top + side))
    if img.size != (spec.square, spec.square):
        img = img.resize((spec.square, spec.square), Image.BICUBIC)

    # One shared round of JPEG so neither class carries a "never compressed"
    # signature. This is applied to real and generated images alike.
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=spec.jpeg_quality, subsampling=2)
    buf.seek(0)
    with Image.open(buf) as out:
        return out.convert("RGB").copy()


def canonicalize_file(src: str | Path, dst: str | Path, spec: CanonicalSpec = CANONICAL_SPEC) -> Path:
    dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(src) as im:
        out = canonicalize(im, spec)
    out.save(dst, format="JPEG", quality=spec.jpeg_quality, subsampling=2)
    return dst
