"""The shortcut audit: how much of our accuracy is not about the picture?

Method: build a feature vector for each image that contains **no pixel content
whatsoever** - only container metadata (dimensions, aspect ratio, file size,
bytes-per-pixel, format, JPEG quantisation-table energy, presence of EXIF).
Train a gradient-boosted tree on that vector alone and measure AUC.

Interpretation:

  AUC ~ 0.50   the two classes are indistinguishable from metadata. Any
               accuracy the real detector reports has to come from content.
  AUC ~ 0.75   there is a real shortcut. Some of the headline number is fake.
  AUC ~ 0.99   the dataset is broken for this purpose. A one-line script beats
               a neural network, and no result from it means anything.

We run this before training, on the raw manifest, and again after
canonicalisation. Reporting both is the cheapest credibility we can buy, and it
is the check that most hackathon submissions skip.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Sequence

import numpy as np

from ..utils.logging import get_logger

log = get_logger("data.shortcuts")

FEATURE_NAMES = [
    "width",
    "height",
    "aspect_ratio",
    "pixels",
    "file_bytes",
    "bytes_per_pixel",
    "is_jpeg",
    "is_png",
    "has_exif",
    "quant_table_mean",
    "quant_table_max",
]


def extract_metadata_features(path: str | Path) -> np.ndarray:
    """Container-only features for one image. No pixels are read as content."""
    from PIL import Image

    path = Path(path)
    try:
        file_bytes = float(path.stat().st_size)
    except OSError:
        file_bytes = 0.0

    width = height = 0
    fmt = ""
    has_exif = 0.0
    q_mean = q_max = 0.0
    try:
        with Image.open(path) as im:
            width, height = im.size
            fmt = (im.format or "").upper()
            try:
                has_exif = 1.0 if im.getexif() else 0.0
            except Exception:
                has_exif = 0.0
            qt = getattr(im, "quantization", None)
            if qt:
                vals = np.concatenate([np.asarray(v, dtype=np.float64).ravel() for v in qt.values()])
                q_mean, q_max = float(vals.mean()), float(vals.max())
    except Exception as exc:  # unreadable file - keep the row, flag it as zeros
        log.debug("metadata probe failed for %s: %s", path, exc)

    pixels = float(width * height)
    return np.array(
        [
            float(width),
            float(height),
            float(width) / float(height) if height else 0.0,
            pixels,
            file_bytes,
            file_bytes / pixels if pixels else 0.0,
            1.0 if fmt in ("JPEG", "JPG", "MPO") else 0.0,
            1.0 if fmt == "PNG" else 0.0,
            has_exif,
            q_mean,
            q_max,
        ],
        dtype=np.float64,
    )


def build_metadata_matrix(paths: Sequence[str | Path]) -> np.ndarray:
    return np.stack([extract_metadata_features(p) for p in paths])


def metadata_leak_probe(
    paths: Sequence[str | Path],
    labels: Sequence[int],
    n_splits: int = 5,
    random_state: int = 1337,
) -> dict:
    """Cross-validated AUC of a metadata-only classifier.

    Returns a dict with the AUC, the per-fold spread, a plain-English verdict
    and the top contributing features - everything needed for the README table.
    """
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.inspection import permutation_importance
    from sklearn.metrics import roc_auc_score
    from sklearn.model_selection import StratifiedKFold

    X = build_metadata_matrix(paths)
    y = np.asarray(labels, dtype=int)

    if len(np.unique(y)) < 2:
        return {"auc": float("nan"), "verdict": "single-class input, probe not meaningful"}

    n_splits = int(min(n_splits, np.bincount(y).min()))
    if n_splits < 2:
        return {"auc": float("nan"), "verdict": "too few samples in the minority class"}

    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    fold_aucs, oof = [], np.zeros(len(y))
    for tr, te in skf.split(X, y):
        clf = HistGradientBoostingClassifier(max_iter=200, random_state=random_state)
        clf.fit(X[tr], y[tr])
        p = clf.predict_proba(X[te])[:, 1]
        oof[te] = p
        fold_aucs.append(roc_auc_score(y[te], p))

    auc = float(roc_auc_score(y, oof))

    clf = HistGradientBoostingClassifier(max_iter=200, random_state=random_state).fit(X, y)
    imp = permutation_importance(clf, X, y, n_repeats=5, random_state=random_state, scoring="roc_auc")
    order = np.argsort(imp.importances_mean)[::-1][:5]

    if auc < 0.60:
        verdict = "clean - metadata carries essentially no class signal"
    elif auc < 0.75:
        verdict = "mild leak - some container-level signal, interpret gains cautiously"
    elif auc < 0.90:
        verdict = "serious leak - a meaningful share of any accuracy is not content-based"
    else:
        verdict = "broken - metadata alone nearly separates the classes; canonicalise before training"

    return {
        "auc": auc,
        "auc_fold_std": float(np.std(fold_aucs)),
        "n_images": int(len(y)),
        "verdict": verdict,
        "top_features": [
            {"name": FEATURE_NAMES[i], "importance": float(imp.importances_mean[i])} for i in order
        ],
    }
