"""Turning folders of images into a manifest, and splitting it honestly.

The split is the part that matters. A random train/test split over a dataset
that contains 6 generators tells you how well the model recognises *those six
generators*, which is not the question anyone cares about - by the time you
ship, there is a seventh. `split_by_family` therefore holds out entire
generator families, so the test set measures the only thing that generalises:
whether the model learned something about synthesis in general.

We report both splits in the write-up. The random-split number is higher and
the family-held-out number is honest; showing the gap is the point.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

from ..utils.io import iter_image_files
from ..utils.logging import get_logger

log = get_logger("data.manifest")

# Folder-name fragments that identify a generator family. Order matters: the
# first match wins, so put more specific names first.
FAMILY_PATTERNS: list[tuple[str, str]] = [
    (r"stable[\-_ ]?diffusion[\-_ ]?xl|sdxl", "sdxl"),
    (r"stable[\-_ ]?diffusion|sd1|sd2|sd[\-_ ]?v?\d", "stable_diffusion"),
    (r"dall[\-_ ]?e|dalle", "dalle"),
    (r"midjourney|mj", "midjourney"),
    (r"flux", "flux"),
    (r"firefly", "firefly"),
    (r"imagen", "imagen"),
    (r"kandinsky", "kandinsky"),
    (r"glide", "glide"),
    (r"vqdm|vq[\-_ ]?diffusion", "vq_diffusion"),
    (r"gan|stylegan|progan|biggan", "gan"),
    (r"coco", "coco"),
    (r"imagenet", "imagenet"),
    (r"laion", "laion"),
    (r"flickr", "flickr"),
]


def infer_family(path: str | Path, default: str = "unknown") -> str:
    """Guess the generator/source family from the path.

    Every public AIGC dataset encodes the generator in the directory name; this
    reads it back out so we can do a family-disjoint split without hand
    labelling 15,000 files.
    """
    s = str(path).lower()
    for pattern, family in FAMILY_PATTERNS:
        if re.search(pattern, s):
            return family
    return default


def build_manifest_from_dirs(
    real_dirs: Sequence[str | Path],
    fake_dirs: Sequence[str | Path],
    source: str = "custom",
    limit_per_class: int | None = None,
    seed: int = 1337,
) -> pd.DataFrame:
    """Manifest from explicit lists of real / AI-generated directories."""
    rows = []
    for label, dirs in ((0, real_dirs), (1, fake_dirs)):
        for d in dirs:
            d = Path(d)
            if not d.exists():
                log.warning("directory does not exist, skipping: %s", d)
                continue
            n = 0
            for p in iter_image_files(d):
                rows.append(
                    {
                        "image_path": str(p),
                        "label": label,
                        "source": source,
                        "family": infer_family(p, "real_photo" if label == 0 else "unknown_gen"),
                    }
                )
                n += 1
            log.info("%s -> %d images (label=%d)", d, n, label)

    df = pd.DataFrame(rows)
    if df.empty:
        raise ValueError("no images found - check the paths passed to build_manifest_from_dirs")
    if limit_per_class:
        df = stratified_subsample(df, per_class=limit_per_class, seed=seed)
    return df.reset_index(drop=True)


def build_manifest_from_labelled_root(
    root: str | Path,
    real_names: Iterable[str] = ("real", "authentic", "nature", "0_real", "coco", "non_aigc"),
    fake_names: Iterable[str] = ("fake", "ai", "synthetic", "1_fake", "aigc", "generated"),
    source: str = "auto",
    limit_per_class: int | None = None,
    seed: int = 1337,
) -> pd.DataFrame:
    """Manifest from a directory tree where some ancestor folder names the class.

    Handles the common layouts without configuration: CIFAKE's
    `train/REAL | train/FAKE`, SID_Set-style `real/ | fully_synthetic/`, and
    WildFake's `<generator>/fake | real` nesting.
    """
    root = Path(root)
    real_names = {n.lower() for n in real_names}
    fake_names = {n.lower() for n in fake_names}

    rows, unmatched = [], 0
    for p in iter_image_files(root):
        parts = [q.lower() for q in p.relative_to(root).parts[:-1]]
        label = None
        for part in reversed(parts):
            if part in fake_names or "fake" in part or "synth" in part:
                label = 1
                break
            if part in real_names or "real" in part:
                label = 0
                break
        if label is None:
            unmatched += 1
            continue
        rows.append(
            {
                "image_path": str(p),
                "label": label,
                "source": source,
                "family": infer_family(p, "real_photo" if label == 0 else "unknown_gen"),
            }
        )

    if unmatched:
        log.warning("%d images had no recognisable real/fake folder and were skipped", unmatched)
    df = pd.DataFrame(rows)
    if df.empty:
        raise ValueError(
            f"no labelled images under {root}. Expected a folder named like "
            f"{sorted(real_names)} or {sorted(fake_names)} somewhere in each path."
        )
    if limit_per_class:
        df = stratified_subsample(df, per_class=limit_per_class, seed=seed)
    return df.reset_index(drop=True)


def stratified_subsample(df: pd.DataFrame, per_class: int, seed: int = 1337) -> pd.DataFrame:
    """Take at most `per_class` images per label, balanced across families.

    Balancing across families inside a class matters: if 80% of the fake images
    came from one generator, a naive subsample gives a model that is really a
    detector for that one generator.
    """
    rng = np.random.default_rng(seed)
    out = []
    for label, grp in df.groupby("label"):
        families = grp["family"].unique()
        quota = max(1, per_class // max(1, len(families)))
        picked = []
        for fam in families:
            sub = grp[grp["family"] == fam]
            take = min(len(sub), quota)
            picked.append(sub.sample(n=take, random_state=int(rng.integers(1 << 31))))
        chosen = pd.concat(picked)
        if len(chosen) < per_class:  # top up from whatever is left
            remainder = grp.drop(chosen.index)
            extra = min(len(remainder), per_class - len(chosen))
            if extra:
                chosen = pd.concat(
                    [chosen, remainder.sample(n=extra, random_state=int(rng.integers(1 << 31)))]
                )
        out.append(chosen.head(per_class))
    return pd.concat(out).sample(frac=1.0, random_state=seed).reset_index(drop=True)


def split_by_family(
    df: pd.DataFrame,
    holdout_families: Sequence[str] | None = None,
    test_frac: float = 0.2,
    seed: int = 1337,
) -> pd.DataFrame:
    """Assign a `split` column, holding out whole generator families for test.

    If `holdout_families` is None we pick the smallest families whose combined
    size first exceeds `test_frac` of the generated images - this keeps as much
    training data as possible while still testing on unseen generators.

    Real images are split randomly: "family" is not a meaningful axis for them,
    and holding out an entire real source would confound generator
    generalisation with domain shift on the real side.
    """
    df = df.copy()
    fake = df[df["label"] == 1]

    if holdout_families is None:
        counts = fake["family"].value_counts(ascending=True)
        target = test_frac * len(fake)
        chosen, running = [], 0
        for fam, n in counts.items():
            if running >= target:
                break
            # Never hold out everything - we still need generated training data.
            if running + n > 0.6 * len(fake):
                continue
            chosen.append(fam)
            running += n
        holdout_families = chosen or [counts.index[0]]

    log.info("held-out generator families: %s", sorted(holdout_families))

    rng = np.random.default_rng(seed)
    split = np.empty(len(df), dtype=object)
    is_fake = (df["label"] == 1).to_numpy()
    in_holdout = df["family"].isin(holdout_families).to_numpy()

    split[is_fake & in_holdout] = "test"
    split[is_fake & ~in_holdout] = "train"

    real_idx = np.where(~is_fake)[0]
    mask = rng.random(len(real_idx)) < test_frac
    split[real_idx[mask]] = "test"
    split[real_idx[~mask]] = "train"

    df["split"] = split
    df.attrs["holdout_families"] = sorted(holdout_families)
    return df


def summarize_manifest(df: pd.DataFrame) -> str:
    """Human-readable summary for the log and the README."""
    lines = [
        f"images: {len(df)}",
        f"  authentic (label=0): {(df['label'] == 0).sum()}",
        f"  generated (label=1): {(df['label'] == 1).sum()}",
    ]
    if "split" in df.columns:
        for split, grp in df.groupby("split"):
            lines.append(
                f"  split={split}: {len(grp)} "
                f"(real {(grp['label'] == 0).sum()}, fake {(grp['label'] == 1).sum()})"
            )
    lines.append("  families:")
    for (fam, label), grp in df.groupby(["family", "label"]):
        lines.append(f"    {fam:<20s} label={label}  n={len(grp)}")
    return "\n".join(lines)
