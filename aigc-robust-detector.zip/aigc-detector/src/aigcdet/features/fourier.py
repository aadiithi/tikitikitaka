"""Optional hand-crafted frequency features, used as an *ablation*, not the model.

Generative upsamplers leave periodic traces in the frequency domain: transposed
convolutions produce a checkerboard whose spectrum has energy spikes at regular
positions, and diffusion decoders tend to under-produce very high frequencies
compared with a camera sensor's noise floor.

These features are cheap (a 2D FFT on a 224x224 greyscale image) and completely
independent of CLIP, which makes them useful for one specific argument in the
write-up: we can show how much of the detector's performance is the classic
"spectral fingerprint" signal, and demonstrate that *that* component is exactly
the part JPEG compression destroys - while the CLIP component survives.

That is the ablation that justifies the whole architecture, so it earns its
place even though these features are not in the shipped model by default.
Enable with `--with-fourier`.
"""

from __future__ import annotations

import numpy as np
from PIL import Image

N_RADIAL_BINS = 24
FOURIER_DIM = N_RADIAL_BINS + 4


def _azimuthal_average(power: np.ndarray, n_bins: int = N_RADIAL_BINS) -> np.ndarray:
    """Mean log-power in `n_bins` concentric rings from DC to Nyquist.

    Collapsing the 2D spectrum to a 1D radial profile makes the feature
    rotation-invariant and tiny, which is what we want for an interpretable
    side-signal.
    """
    h, w = power.shape
    cy, cx = h / 2.0, w / 2.0
    y, x = np.ogrid[:h, :w]
    r = np.sqrt((y - cy) ** 2 + (x - cx) ** 2)
    r_max = r.max()
    bins = np.clip((r / r_max * n_bins).astype(int), 0, n_bins - 1)
    out = np.zeros(n_bins, dtype=np.float32)
    for b in range(n_bins):
        m = bins == b
        out[b] = power[m].mean() if m.any() else 0.0
    return out


def fourier_features(img: Image.Image, size: int = 224) -> np.ndarray:
    """A compact spectral descriptor: radial profile plus four summary stats."""
    g = np.asarray(img.convert("L").resize((size, size), Image.BICUBIC), dtype=np.float32) / 255.0
    g = g - g.mean()
    # Hann window, so the image border does not create a cross-shaped artefact
    # in the spectrum that would swamp the real signal.
    win = np.outer(np.hanning(size), np.hanning(size)).astype(np.float32)
    spec = np.fft.fftshift(np.fft.fft2(g * win))
    power = np.log1p(np.abs(spec) ** 2)

    radial = _azimuthal_average(power)
    total = float(power.sum()) + 1e-8
    high_band = radial[int(0.7 * N_RADIAL_BINS) :].mean()
    low_band = radial[: int(0.2 * N_RADIAL_BINS)].mean()

    extras = np.array(
        [
            high_band,
            low_band,
            high_band / (low_band + 1e-8),          # spectral slope proxy
            float(power.std()) / (total / power.size),  # spikiness -> periodic artefacts
        ],
        dtype=np.float32,
    )
    feats = np.concatenate([radial, extras])
    return feats / (np.linalg.norm(feats) + 1e-8)
