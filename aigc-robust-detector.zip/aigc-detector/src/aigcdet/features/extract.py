"""Feature extraction with caching.

This is the only expensive step in the project. Everything downstream reads a
`.npz` bundle, which is why the whole clean-vs-augmented experiment can be
re-run in seconds.

Two modes:

* `n_views=1`, no policy   -> the clean feature bank. One row per image.
* `n_views=k`, with policy -> the augmented bank. Each image contributes k rows,
  each damaged independently. Labels and a `source_index` column are repeated so
  we can always trace a row back to its file.

The augmented bank is what makes the model robust; the clean bank is the
control we compare it against. Producing both from the same image list is what
makes that comparison fair.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Sequence

import numpy as np

from ..aug.transforms import TrainDamagePolicy
from ..data.normalize import CANONICAL_SPEC, canonicalize
from ..utils.io import ensure_dir, load_image
from ..utils.logging import get_logger

log = get_logger("features.extract")


@dataclass
class FeatureBundle:
    """Features plus everything needed to interpret them later."""

    features: np.ndarray            # (N, D) float32
    labels: np.ndarray              # (N,) int
    source_index: np.ndarray        # (N,) index into `paths`
    paths: list[str]                # unique image paths
    meta: dict = field(default_factory=dict)

    def save(self, path: str | Path) -> Path:
        p = Path(path)
        ensure_dir(p.parent)
        np.savez_compressed(
            p,
            features=self.features,
            labels=self.labels,
            source_index=self.source_index,
            paths=np.array(self.paths, dtype=object),
            meta=np.array([repr(self.meta)], dtype=object),
        )
        log.info("saved %s  features=%s", p, self.features.shape)
        return p

    @classmethod
    def load(cls, path: str | Path) -> "FeatureBundle":
        z = np.load(path, allow_pickle=True)
        meta = {}
        try:
            meta = eval(str(z["meta"][0]), {"__builtins__": {}}, {"nan": float("nan")})
        except Exception:
            pass
        return cls(
            features=z["features"],
            labels=z["labels"],
            source_index=z["source_index"],
            paths=list(z["paths"]),
            meta=meta if isinstance(meta, dict) else {},
        )

    def __len__(self) -> int:
        return len(self.labels)


def extract_features(
    backbone,
    paths: Sequence[str | Path],
    labels: Sequence[int] | None = None,
    n_views: int = 1,
    policy: TrainDamagePolicy | None = None,
    canonical: bool = True,
    batch_size: int = 32,
    with_fourier: bool = False,
    progress: bool = True,
) -> FeatureBundle:
    """Encode `paths`, optionally producing `n_views` damaged copies per image.

    Unreadable files are skipped with a warning rather than aborting the run -
    losing one corrupt JPEG four hours into extraction should not cost the run.
    """
    from tqdm.auto import tqdm

    paths = [str(p) for p in paths]
    labels = list(labels) if labels is not None else [0] * len(paths)
    if len(labels) != len(paths):
        raise ValueError("paths and labels must be the same length")

    if n_views > 1 and policy is None:
        raise ValueError("n_views > 1 requires a TrainDamagePolicy - otherwise the copies are identical")

    feats_out: list[np.ndarray] = []
    lab_out: list[int] = []
    idx_out: list[int] = []
    skipped = 0

    iterator = range(0, len(paths), batch_size)
    if progress:
        iterator = tqdm(iterator, desc=f"encode (views={n_views})", unit="batch")

    for start in iterator:
        chunk_paths = paths[start : start + batch_size]
        chunk_labels = labels[start : start + batch_size]

        images, keep_idx = [], []
        for j, p in enumerate(chunk_paths):
            try:
                im = load_image(p)
            except Exception as exc:
                log.warning("skipping unreadable image %s (%s)", p, exc)
                skipped += 1
                continue
            if canonical:
                im = canonicalize(im, CANONICAL_SPEC)
            images.append(im)
            keep_idx.append(j)

        if not images:
            continue

        for _view in range(n_views):
            # Each view is damaged independently, so two views of the same
            # image see different corruptions - that is the whole point.
            batch = [policy(im) for im in images] if policy is not None else images
            f = backbone.encode(batch, batch_size=batch_size)
            if with_fourier:
                from .fourier import fourier_features

                ff = np.stack([fourier_features(im) for im in batch]).astype(np.float32)
                f = np.concatenate([f, ff], axis=1)
            feats_out.append(f)
            lab_out.extend(chunk_labels[j] for j in keep_idx)
            idx_out.extend(start + j for j in keep_idx)

    if not feats_out:
        raise RuntimeError("no images could be encoded - every file failed to load")

    if skipped:
        log.warning("%d/%d images were skipped as unreadable", skipped, len(paths))

    features = np.concatenate(feats_out, axis=0).astype(np.float32)
    bundle = FeatureBundle(
        features=features,
        labels=np.array(lab_out, dtype=np.int64),
        source_index=np.array(idx_out, dtype=np.int64),
        paths=paths,
        meta={
            "backbone": backbone.name,
            "dim": int(features.shape[1]),
            "n_views": n_views,
            "canonical": canonical,
            "canonical_spec": CANONICAL_SPEC.as_dict() if canonical else None,
            "with_fourier": with_fourier,
            "damage_policy": policy.describe() if policy else None,
            "n_skipped": skipped,
        },
    )
    log.info(
        "extracted %s from %d images (%d views each)", bundle.features.shape, len(paths), n_views
    )
    return bundle


def extract_features_for_manifest(
    backbone,
    manifest,
    split: str | None = None,
    **kwargs,
) -> FeatureBundle:
    """Convenience wrapper: filter a manifest by split, then extract."""
    df = manifest if split is None else manifest[manifest["split"] == split]
    if len(df) == 0:
        raise ValueError(f"manifest has no rows for split={split!r}")
    bundle = extract_features(
        backbone, df["image_path"].tolist(), df["label"].tolist(), **kwargs
    )
    bundle.meta["split"] = split
    bundle.meta["families"] = sorted(df["family"].unique().tolist())
    return bundle
