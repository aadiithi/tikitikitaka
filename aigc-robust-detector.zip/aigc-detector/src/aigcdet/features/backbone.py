"""The frozen backbone.

We do not fine-tune. The vision tower's weights never move; we compute one
embedding per image and train a small head on top. Three reasons, and they are
the same three we give the judges:

* **Iteration speed.** Features are computed once and cached. Every subsequent
  experiment - clean vs augmented training, head architecture, threshold
  choice, ablations - is a few seconds on CPU instead of an hour on a GPU we
  are renting for free and can be disconnected from at any moment.

* **Generalisation.** Fine-tuning a whole ViT on a few thousand images from six
  generators is an efficient way to memorise those six generators. A frozen
  general-purpose representation cannot overfit to generator fingerprints
  because it was never allowed to move toward them. This is the finding from
  the recent AIGC-detection literature that we are leaning on.

* **Deployability.** The backbone is a fixed, shareable artefact. A platform
  running this at scale computes embeddings once per upload and can retrain or
  re-threshold the head daily as new generators appear, without touching the
  expensive part. That is the operational story behind the Feasibility score.

`load_backbone("dummy")` returns a deterministic random-projection encoder with
no downloads. It exists so the full pipeline, the tests and `predict.py` can be
exercised on a machine with no network and no GPU - which is how the repository
is smoke-tested in CI.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Sequence

import numpy as np
from PIL import Image

from ..utils.logging import get_logger

log = get_logger("features.backbone")

BACKBONE_PRESETS = {
    # name -> (open_clip model, pretrained tag, embedding dim, approx vision params)
    "clip-vit-l14": ("ViT-L-14", "openai", 768, "304M"),
    "clip-vit-b16": ("ViT-B-16", "openai", 512, "86M"),
    "clip-vit-b32": ("ViT-B-32", "openai", 512, "88M"),
    "clip-vit-l14-datacomp": ("ViT-L-14", "datacomp_xl_s13b_b90k", 768, "304M"),
    "dummy": (None, None, 512, "0"),
}


@dataclass
class Backbone:
    """A frozen image encoder: PIL images in, L2-normalised embeddings out."""

    name: str
    dim: int
    device: str
    _encode_batch: Callable[[List[Image.Image]], np.ndarray]
    param_note: str = ""

    def encode(self, images: Sequence[Image.Image], batch_size: int = 32) -> np.ndarray:
        """Encode a list of PIL images to an (N, dim) float32 array."""
        if not images:
            return np.zeros((0, self.dim), dtype=np.float32)
        out = []
        for i in range(0, len(images), batch_size):
            out.append(self._encode_batch(list(images[i : i + batch_size])))
        feats = np.concatenate(out, axis=0).astype(np.float32)
        # L2-normalise: the head then works on direction only, which makes it
        # insensitive to the global contrast/brightness shifts that colour
        # jitter introduces.
        norms = np.linalg.norm(feats, axis=1, keepdims=True)
        return feats / np.clip(norms, 1e-8, None)


def _resolve_device(device: str | None) -> str:
    if device:
        return device
    try:
        import torch

        if torch.cuda.is_available():
            return "cuda"
        if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            return "mps"
    except ImportError:
        pass
    return "cpu"


def _load_dummy(dim: int, device: str) -> Backbone:
    """Deterministic hash-based projection. Not a detector - a test double.

    Downsamples to 32x32, flattens, and projects through a fixed random matrix.
    Carries just enough signal that an end-to-end pipeline test is meaningful,
    while requiring no weights and no network.
    """
    rng = np.random.default_rng(0)
    proj = rng.normal(0, 1.0 / np.sqrt(3072), size=(3072, dim)).astype(np.float32)

    def encode_batch(images: List[Image.Image]) -> np.ndarray:
        arrs = []
        for im in images:
            small = im.convert("RGB").resize((32, 32), Image.BILINEAR)
            arrs.append(np.asarray(small, dtype=np.float32).ravel() / 255.0)
        return np.stack(arrs) @ proj

    log.warning("using the DUMMY backbone - for smoke tests only, not a real detector")
    return Backbone(name="dummy", dim=dim, device="cpu", _encode_batch=encode_batch, param_note="0")


def _load_open_clip(model_name: str, pretrained: str, dim: int, device: str, note: str) -> Backbone:
    import open_clip
    import torch

    model, _, preprocess = open_clip.create_model_and_transforms(model_name, pretrained=pretrained)
    model = model.to(device).eval()
    for p in model.parameters():  # frozen, explicitly and verifiably
        p.requires_grad_(False)

    autocast = torch.autocast(device_type="cuda", dtype=torch.float16) if device == "cuda" else None

    @torch.no_grad()
    def encode_batch(images: List[Image.Image]) -> np.ndarray:
        batch = torch.stack([preprocess(im) for im in images]).to(device)
        if autocast is not None:
            with torch.autocast(device_type="cuda", dtype=torch.float16):
                feats = model.encode_image(batch)
        else:
            feats = model.encode_image(batch)
        return feats.float().cpu().numpy()

    return Backbone(
        name=f"open_clip:{model_name}/{pretrained}",
        dim=dim,
        device=device,
        _encode_batch=encode_batch,
        param_note=note,
    )


def _load_hf_clip(hf_id: str, dim: int, device: str) -> Backbone:
    import torch
    from transformers import CLIPImageProcessor, CLIPVisionModelWithProjection

    processor = CLIPImageProcessor.from_pretrained(hf_id)
    model = CLIPVisionModelWithProjection.from_pretrained(hf_id).to(device).eval()
    for p in model.parameters():
        p.requires_grad_(False)

    @torch.no_grad()
    def encode_batch(images: List[Image.Image]) -> np.ndarray:
        inputs = processor(images=images, return_tensors="pt").to(device)
        return model(**inputs).image_embeds.float().cpu().numpy()

    return Backbone(
        name=f"hf:{hf_id}", dim=dim, device=device, _encode_batch=encode_batch, param_note="304M"
    )


def load_backbone(name: str = "clip-vit-l14", device: str | None = None) -> Backbone:
    """Load a frozen encoder by preset name, HF id, or the literal 'dummy'.

    Falls back to open_clip -> transformers -> dummy, logging loudly at each
    step, so that a missing optional dependency degrades to something runnable
    rather than a stack trace during a demo.
    """
    device = _resolve_device(device)

    if name == "dummy":
        return _load_dummy(BACKBONE_PRESETS["dummy"][2], device)

    if name in BACKBONE_PRESETS:
        model_name, pretrained, dim, note = BACKBONE_PRESETS[name]
        try:
            return _load_open_clip(model_name, pretrained, dim, device, note)
        except Exception as exc:
            log.warning("open_clip load failed (%s); trying transformers", exc)
        hf_map = {
            "clip-vit-l14": "openai/clip-vit-large-patch14",
            "clip-vit-b16": "openai/clip-vit-base-patch16",
            "clip-vit-b32": "openai/clip-vit-base-patch32",
        }
        if name in hf_map:
            try:
                return _load_hf_clip(hf_map[name], dim, device)
            except Exception as exc:
                log.warning("transformers load failed (%s)", exc)
        raise RuntimeError(
            f"could not load backbone '{name}'. Install `open_clip_torch` or "
            f"`transformers`, or pass --backbone dummy for an offline smoke test."
        )

    # Treat anything else as a HuggingFace model id.
    return _load_hf_clip(name, 768, device)
